<?php 



$bot_token = "";
$chat_id = "";
$apple_pay = "1";

$rezmail = "";


$onlycards = "1"; // 1 or 0

?>