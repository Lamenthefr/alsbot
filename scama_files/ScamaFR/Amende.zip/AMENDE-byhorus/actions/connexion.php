<?php

    session_start();
    require("../config.php");

  
    header("Location: ../contraventions-ratachees.php");
die();
